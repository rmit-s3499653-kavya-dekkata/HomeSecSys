package handle;

import java.io.IOException;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class UploadData  implements RequestHandler<Object, Object>{
	public Object handleRequest(Object input, Context context){
        context.getLogger().log("Input: " + input);

        try {
			s3UploadFunction.uploadData();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // TODO: implement your handler
        return "complete!!!";
    }
}
