package handle;


import java.sql.Timestamp;
import java.util.Random;

public class GenerateData {

	public StringBuffer generateData(){
		java.util.Date date= new java.util.Date();
		String currentTime = new Timestamp(date.getTime()).toString();  
		

		String[][] data = {
				{"D101", "Door", "locked", "unlocked", "broken"},
				{"D102", "Window", "locked","unlocked","broken"},
				{"D103","Glass", "locked","unlocked","broken"},
				{"D104","Thermostat", ""},
				{"D105","Camera","active","inactive"},
				{"D106","Lights","on","off"},
				{"D107","FireAlarm","normal","triggered"}
		};

		StringBuffer randData = new StringBuffer();
		String message;
		int k = 0;
		Random random = new Random();
		while(k < 7) {
			String deviceStatus = "";
			int i = k%7;
			randData.append("\""+currentTime+data[i][0]+"\",");

			for(int j=0; j < 3; j++){
				if(j == 2){
					if(data[i][1].equalsIgnoreCase("thermostat")){
						deviceStatus = Integer.toString((random.nextInt(40)+5));
						randData.append("\""+ deviceStatus +"\",");
					}
					else{
						int index = random.nextInt(data[i].length-2)+2;
						//System.out.println(data[i][index]);
						deviceStatus = data[i][index];
						randData.append("\""+deviceStatus +"\",");
					}
				}
				else{
					randData.append("\""+data[i][j]+"\",");
				}
			}
			message = data[i][1] +" with Device ID "+ data[i][0] +" current status is "+ deviceStatus +".";
			randData.append("\""+message+"\"\n");
			k++;
		}
		return randData;
	}

}
