package handle;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.PutObjectRequest;

public class s3UploadFunction {
	

	private static String bucketName     = "praveenscloudlab5";
	private static String keyName        = "dataFile.csv";

	public static void uploadData() throws IOException {
		
		BasicAWSCredentials awsCreds = new BasicAWSCredentials("AKIAJJ2F65SZL3N3X3NA", "euDvbbgv/eL7UsMbcjviXcNwT8y/V9kbc5xJinxW");
		AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
		                       .withCredentials(new AWSStaticCredentialsProvider(awsCreds))
		                       .build();
		
		try {
			System.out.println("Uploading a new object to S3 from a file\n");
		//	File file = new File(uploadFileName);
			s3Client.putObject(new PutObjectRequest(
					bucketName, keyName, createSampleFile()));

		} catch (AmazonServiceException ase) {
			System.out.println("Caught an AmazonServiceException, which " +
					"means your request made it " +
					"to Amazon S3, but was rejected with an error response" +
					" for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out.println("Caught an AmazonClientException, which " +
					"means the client encountered " +
					"an internal error while trying to " +
					"communicate with S3, " +
					"such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		}
	}
	
	
	  private static File createSampleFile() throws IOException {
	        File file = File.createTempFile("aws-java-sdk-", ".csv");
	        file.deleteOnExit();

	        Writer writer = new OutputStreamWriter(new FileOutputStream(file));
	        writer.write(new GenerateData().generateData().toString());
	        writer.close();

	        return file;
	    }
}
