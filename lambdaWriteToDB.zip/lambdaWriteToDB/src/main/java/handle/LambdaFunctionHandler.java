package handle;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;

public class LambdaFunctionHandler implements RequestHandler<S3Event, Object> {

	
    public String handleRequest(S3Event input, Context context) {
        context.getLogger().log("Input: " + input);
        DeviceStatus dev = new DeviceStatus();
        boolean status = dev.insertAllStudents(input);
        if(!status)
        context.getLogger().log("Failed!!");
        else
        	context.getLogger().log("Success");
        return status+"";
    }

}
