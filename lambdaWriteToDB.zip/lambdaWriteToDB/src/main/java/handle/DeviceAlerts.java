package handle;

import java.util.ArrayList;

public class DeviceAlerts {

	private Device alert = null;

//	w

	public Device computeAlert(String name, String status, String message){

        System.out.println("inside alert " + name + status + message);
        
        if((name.equalsIgnoreCase("\"door\"")) || (name.equalsIgnoreCase("\"window\""))
                || (name.equalsIgnoreCase("\"glass\""))){
            if((status.equalsIgnoreCase("\"unlocked\"")) || (status.equalsIgnoreCase("\"broken\""))){
                return new Device(name,status,message);
            }
        }
        if((name.equalsIgnoreCase("\"camera")) && (status.equalsIgnoreCase("\"inactive\""))){
            return new Device(name,status,message);
        }
        if((name.equalsIgnoreCase("\"lights\"")) && (status.equalsIgnoreCase("\"off\""))){
            return new Device(name,status,message);
        }
        if((name.equalsIgnoreCase("\"fireAlaram\"")) && (status.equalsIgnoreCase("\"triggered\""))){
            return new Device(name,status,message);
        }
        if(name.equalsIgnoreCase("\"thermostat\"")){
            String temp = status.replace("\"", " ");
            System.out.println("termo "+ temp);
            if(Integer.parseInt(temp.trim()) > 40){
                return new Device(name,status,message);
            }
        }
        return null;

    }
}
