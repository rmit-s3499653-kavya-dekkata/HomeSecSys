package handle;

public class Device {

	private String deviceId;
	private String deviceName;
	private String deviceStatus;
	private String deviceMessage;
	
	public Device(String deviceId, String deviceName, String deviceStatus, String message) {
		this.deviceId = deviceId;
		this.deviceName = deviceName;
		this.deviceStatus = deviceStatus;
		this.deviceMessage = message;
	}
	
	public Device(String deviceName, String deviceStatus, String message) {
		this.deviceName = deviceName;
		this.deviceStatus = deviceStatus;
		this.deviceMessage = message;
	}
	
	public String getDeviceMessage() {
		return deviceMessage;
	}

	public void setDeviceMessage(String deviceMessage) {
		this.deviceMessage = deviceMessage;
	}

	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public String getDeviceStatus() {
		return deviceStatus;
	}
	public void setDeviceStatus(String deviceStatus) {
		this.deviceStatus = deviceStatus;
	}
}